import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-experience-image',
  templateUrl: './experience-image.component.html',
  styleUrls: ['./experience-image.component.css']
})
export class ExperienceImageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
