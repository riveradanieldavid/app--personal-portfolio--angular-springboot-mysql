import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-experience-text',
  templateUrl: './experience-text.component.html',
  styleUrls: ['./experience-text.component.css']
})
export class ExperienceTextComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
