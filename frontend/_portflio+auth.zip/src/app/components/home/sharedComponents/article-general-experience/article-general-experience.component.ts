import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-article-general-experience',
  templateUrl: './article-general-experience.component.html',
  styleUrls: ['./article-general-experience.component.css']
})
export class ArticleGeneralExperienceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
