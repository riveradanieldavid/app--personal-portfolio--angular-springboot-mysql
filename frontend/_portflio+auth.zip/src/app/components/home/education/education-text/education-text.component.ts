import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-education-text',
  templateUrl: './education-text.component.html',
  styleUrls: ['./education-text.component.css']
})
export class EducationTextComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
