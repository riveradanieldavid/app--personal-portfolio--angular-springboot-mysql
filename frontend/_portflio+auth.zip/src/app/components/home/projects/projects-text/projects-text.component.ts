import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-projects-text',
  templateUrl: './projects-text.component.html',
  styleUrls: ['./projects-text.component.css']
})
export class ProjectsTextComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
