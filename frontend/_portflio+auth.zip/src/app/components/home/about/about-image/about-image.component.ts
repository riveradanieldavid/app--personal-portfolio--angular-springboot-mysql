import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-about-image',
  templateUrl: './about-image.component.html',
  styleUrls: ['./about-image.component.css']
})
export class AboutImageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
