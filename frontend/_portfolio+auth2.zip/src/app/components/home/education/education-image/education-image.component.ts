import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-education-image',
  templateUrl: './education-image.component.html',
  styleUrls: ['./education-image.component.css']
})
export class EducationImageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
