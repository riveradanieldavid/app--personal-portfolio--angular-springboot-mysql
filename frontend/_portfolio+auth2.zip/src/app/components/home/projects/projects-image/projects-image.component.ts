import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-projects-image',
  templateUrl: './projects-image.component.html',
  styleUrls: ['./projects-image.component.css']
})
export class ProjectsImageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
